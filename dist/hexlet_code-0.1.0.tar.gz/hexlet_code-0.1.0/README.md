### Hexlet tests and linter status:
[![Actions Status](https://github.com/Darja86/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Darja86/python-project-lvl1/actions)